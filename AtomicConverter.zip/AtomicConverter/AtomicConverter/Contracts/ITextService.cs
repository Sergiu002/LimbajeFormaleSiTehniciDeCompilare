namespace AtomicConverter.Contracts
{
    public interface ITextService
    {
        /// <summary>
        /// Split a text
        /// </summary>
        /// <param name="text">The text from request</param>
        void SplitText(string text);
    }
}