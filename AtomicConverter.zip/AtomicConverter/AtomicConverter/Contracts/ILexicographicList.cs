namespace AtomicConverter.Contracts
{
    public interface ILexicographicList<T> where T: IComparable<T>
    { 
        void Add(T item);
        void Remove(T item);
        public int GetIndex(T item);
        void Print();
    }
}