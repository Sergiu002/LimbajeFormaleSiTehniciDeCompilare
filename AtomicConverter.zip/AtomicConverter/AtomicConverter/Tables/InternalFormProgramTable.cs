using AtomicConverter.Utils;

namespace AtomicConverter.Tables
{
    public class InternalFormProgramTable
    {
        private List<TokenPositionHolder> _pifTable;

        public InternalFormProgramTable()
        {
            _pifTable = new List<TokenPositionHolder>();
        }


        public void AddSymbol(string code, string token, int position)
        {
            _pifTable.Add(new TokenPositionHolder {Code = code, Token = token, Position = position });
        }

        /// <summary>
        /// In case we make a change to the alphabetical order we update the code that the value had previously to the new code
        /// </summary>
        /// <param name="oldPosition">The old position of the token in SymbolTable</param>
        /// <param name="newPosition">The new position</param>
        public void UpdateCode(int oldPosition, int newPosition)
        {
            foreach (var symbol in _pifTable)
            {
                if (symbol.Position == oldPosition)
                {
                    symbol.Position = newPosition;
                }
            }
        }

        /// <summary>
        /// Return the internal table for parsing
        /// </summary>
        /// <returns></returns>
        public List<TokenPositionHolder> GetTable()
        {
            return _pifTable;
        }

        public new string ToString()
        {
            return _pifTable.Aggregate(string.Empty, (current, token) => current + (token.ToString() + '\n'));
        }
    }
}