using AtomicConverter.Utils;

namespace AtomicConverter.Tables
{
    public class SymbolTable
    {
        private LexicographicList<string> _symbolTable;

        public SymbolTable()
        {
            _symbolTable = new LexicographicList<string>();
        }

        public void Add(string value)
        {
            _symbolTable.Add(value);
        }

        public void Remove(string value)
        {
            _symbolTable.Remove(value);
        }

        public int GetIndex(string value)
        {
            return _symbolTable.GetIndex(value);
        }

        public new string ToString()
        {
            string sequence = string.Empty;
            for (int i = 0; i < _symbolTable.Length(); i++)
            {
                sequence += _symbolTable.GetItem(i) + '\n';
            }

            return sequence;
        }
    }
}