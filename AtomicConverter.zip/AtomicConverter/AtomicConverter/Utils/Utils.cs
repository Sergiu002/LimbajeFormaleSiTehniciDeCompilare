using System.Collections;
using System.Text;
using AtomicConverter.Tables;

namespace AtomicConverter.Utils
{
    public static class Utils
    {
        public static IEnumerable<string> GetStringsFromFile(string path)
        {
            char[] separators = {'\n', '\r', '\t'};
            StringBuilder data = new();
            
            if (File.Exists(path)) { 
                // Reads file line by line 
                StreamReader file = new StreamReader(path); 
                string line; 
  
                while ((line = file.ReadLine()) != null) { 
                    data.AppendLine(line); 
                } 
  
                file.Close(); 
            } 

            IEnumerable<string> words = data.ToString()
                                            .Split(separators)
                                            .Where(w => w != "");
            
            return words;
        }
        
        public static Dictionary<string, string> ReadCodesAtoms()
        {
            string path = Constants.INPUT_PATH;
            StringBuilder data = new();
            using(FileStream fs = File.Open(path, FileMode.Open))
            {
                byte[] b = new byte[1024];
                UTF8Encoding temp = new (true);
 
                while (fs.Read(b, 0, b.Length) > 0) {
                    data.AppendLine(temp.GetString(b));
                }
            }
            
            char[] separators = {'\n', '\r', '\t'};
            string atoms = data.ToString();
            string[] a = atoms.Split(separators);
            List<string[]> values = a.Where(x => x != string.Empty)
                                     .Select(x => x.Split(' '))
                                     .ToList();
            
            Dictionary<string, string> keyValue = new();
            foreach (var value in values)
            {
                if (value.Length == 2)
                {
                    keyValue.Add(value[0], value[1]);
                }
                else
                {
                    throw new InvalidDataException();
                }
            }

            return keyValue;
        }
        
        public static List<string> AttemptSplit(string word)
        {
            var specialChars = new List<char> { '[', ']', ':', ';', '{', '}', '(', ')', '=', '!', '>', '<', '+', '-', '/', '%', ',', '*', '?', '.' };
            var words = new List<string>();
            
            var startPos = 0;
            var nextPos = 1;
            var currentWord = string.Empty;
            if (word.Length == 1)
            {
                words.Add(word);
            }
            else
            {
                while (startPos < word.Length - 1)
                {
                    if (!specialChars.Contains(word[startPos]))
                    {
                        currentWord += word[startPos];
                    }
                    else
                    {
                        if (!string.IsNullOrEmpty(currentWord))
                        {
                            words.Add(currentWord);
                            currentWord = string.Empty;
                        }

                        if (word[startPos] == '!' || word[startPos] == '>' || word[startPos] == '<' || word[startPos] == '=')
                        {
                            if (word[startPos] == '<')
                            {
                                if (word[nextPos] == '<')
                                {
                                    words.Add(string.Empty + word[startPos] + word[nextPos]);
                                    nextPos += 1;
                                }
                                else
                                {
                                    words.Add(string.Empty + word[startPos]);
                                }
                            }
                            else if (word[startPos] == '>')
                            {
                                if (word[nextPos] == '>')
                                {
                                    words.Add(string.Empty + word[startPos] + word[nextPos]);
                                    nextPos += 1;
                                }
                                else
                                {
                                    words.Add(string.Empty + word[startPos]);
                                }
                            }
                            else if (word[startPos] == '=')
                            {
                                if (word[nextPos] == '=')
                                {
                                    words.Add(string.Empty + word[startPos] + word[nextPos]);
                                    nextPos += 1;
                                }
                                else
                                {
                                    words.Add(string.Empty + word[startPos]);
                                }
                            }
                            else if (word[startPos] == '!')
                            {
                                if (word[nextPos] == '=')
                                {
                                    words.Add(string.Empty + word[startPos] + word[nextPos]);
                                    nextPos += 1;
                                }
                                else
                                {
                                    words.Add(string.Empty + word[startPos]);
                                }
                            }
                            else
                            {
                                words.Add(string.Empty + word[startPos]);
                            }
                        }
                        else
                        {
                            words.Add(string.Empty + word[startPos]);
                        }

                    }
                    startPos = nextPos;
                    nextPos++;

                    if (nextPos == word.Length)
                    {
                        if (specialChars.Contains(word[nextPos - 1]))
                        {
                            if (!string.IsNullOrEmpty(currentWord))
                            {
                                words.Add(currentWord);
                                currentWord = string.Empty;
                            }
                            words.Add(string.Empty + word[nextPos - 1]);
                        }
                        else
                        {
                            currentWord += word[nextPos - 1];
                            words.Add(currentWord);
                            currentWord = string.Empty;
                        }
                    }
                }
            }			
			
            return words; 
        }
        
        private static string GetSequence(IEnumerable<string> list)
        {
            return list.Aggregate(String.Empty, (current, item) => current + (item + '\n'));
        }
        
        public static void WriteInSymbolTableFile(this SymbolTable table) 
        {
            using StreamWriter writer = new(Constants.OUTPUT_SYMBOL_TABLE_PATH);
            writer.WriteLine("CODES:\n" + table.ToString()  + "\n");
            writer.Close();
        }
        
        public static void WriteInLexicalErrorsFile(this List<TokenPositionHolder> error)
        {
            string sequence = error.Aggregate(string.Empty, (current, token) => current + (token.ToString() + '\n'));
            using StreamWriter writer = new(Constants.OUTPUT_LEXICAL_ERRORS_PATH);
            writer.WriteLine("Position    Token\n" + sequence  + "\n");
            writer.Close();
        }
        
        public static void WriteInInternalFormProgramTableFile(this InternalFormProgramTable table) 
        {
            using StreamWriter writer = new(Constants.OUTPUT_INTERNAL_FORM_PROGRAM_TABLE_PATH);
            writer.WriteLine("CODE    Position    Token\n" + table.ToString()  + "\n");
            writer.Close();
        }
    }
}