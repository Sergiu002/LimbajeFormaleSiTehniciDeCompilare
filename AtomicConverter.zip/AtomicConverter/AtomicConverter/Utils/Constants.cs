namespace AtomicConverter.Utils
{
    internal static class Constants
    {
        public const string OPERATORS_REGEX = "(?<![<>=+\\-*\\/]|#include\\s)([+\\-*=\\\\<>]=?|<<|>>|[<>]=)(?![<>=])";
        public const string CONSTANTS_REGEX = "[0-9]\\.\\d*|\\d";
        public const string SEPARATORS_REGEX = "[,;(){}[\\]:]";
        public const string KEYWORDS_REGEX = "#include|using|namespace|std|int|double|void|M_PI|else|endl|main|cin|cout|double|if|while/gm";
        public const string LETTERS_DIGITS_REGEX = "^[-+a-zA-Z0-9]*$";
        public const string LETTERS_REGEX = "^[a-zA-Z]*$";
        public const string NUMBER_REGEX = "^-?[0-9]+$";	
        public const string INPUT_PATH = BASE_PATH + "Input.txt";
        public const string OUTPUT_LEXICAL_ERRORS_PATH = BASE_PATH + "OutputLexicalErrors.txt";
        public const string OUTPUT_INTERNAL_FORM_PROGRAM_TABLE_PATH = BASE_PATH + "OutputInternalFormProgramTable.txt";
        public const string OUTPUT_SYMBOL_TABLE_PATH = BASE_PATH + "OutputSymbolTable.txt";
        public const string OPERATORS_PATH = BASE_PATH + "Operators.txt";
        public const string SEPARATORS_PATH = BASE_PATH + "Separators.txt";
        public const string KEYWORDS_PATH = BASE_PATH + "Keywords.txt";
        private const string BASE_PATH = "C:\\Facultate\\LFTC\\AtomicConverter\\AtomicConverter\\";
        public const string IDENTIFIER = "ID";
        public const string CONSTANT = "CONST";
    }
}