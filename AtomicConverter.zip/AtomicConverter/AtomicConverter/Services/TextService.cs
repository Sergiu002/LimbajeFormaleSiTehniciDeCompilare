using System.Text;
using System.Text.RegularExpressions;
using AtomicConverter.Contracts;
using AtomicConverter.DataStructures;
using AtomicConverter.Tables;
using AtomicConverter.Utils;

namespace AtomicConverter.Services
{
    public class TextService: ITextService
    {
        public TextService()
        {
            
        }

        public void SplitText(string text)
        {
            Main(text);   
        }
        
        private static void Main(string text)
        {
            try
            {
                Outputs outputs = FindAtomsFromText(text);
                outputs.SymbolTable.WriteInSymbolTableFile();
                outputs.InternalFormProgramTable.WriteInInternalFormProgramTableFile();
                outputs.LexicalErrors.WriteInLexicalErrorsFile();
                
            } catch (FileNotFoundException)
            {
                throw new FileNotFoundException();
            } catch (IOException) {
                throw new IOException();
            }
        }

        private static void PutAtomsInTables(SymbolTable symbolTable, 
                                             InternalFormProgramTable internalFormProgramTable, 
                                             List<TokenPositionHolder> errors, 
                                             Dictionary<string, string> keyValue, 
                                             IEnumerable<string> atoms, 
                                             int fileLine)
        {
            IList<string> operators = Utils.Utils.GetStringsFromFile(Constants.OPERATORS_PATH).ToList();
            IList<string> separators = Utils.Utils.GetStringsFromFile(Constants.SEPARATORS_PATH).ToList();
            IList<string> keywords = Utils.Utils.GetStringsFromFile(Constants.KEYWORDS_PATH).ToList();
            
            Regex lettersDigitsRegex = new(Constants.LETTERS_DIGITS_REGEX);
            Regex lettersRegex = new(Constants.LETTERS_REGEX);
            Regex numberRegex = new(Constants.NUMBER_REGEX);		
            
            foreach (string atom in atoms)
            {
                if (keywords.Contains(atom) || operators.Contains(atom) || separators.Contains(atom))
                {
                    internalFormProgramTable.AddSymbol(keyValue[atom], atom, 0);
                }
                else if (lettersDigitsRegex.IsMatch(atom))
                {
                    var symbolType = Constants.IDENTIFIER;
                    var hasError = false;
                    
                    if (lettersRegex.IsMatch(atom))
                    {
                        if (atom.Length <= 8) // identifers are allowed to have at max 8 chars
                        {
                            symbolType = Constants.IDENTIFIER;
                        }
                        else
                        {
                            hasError = true;
                        }
										
                    }
                    else if (numberRegex.IsMatch(atom))
                    {
                        symbolType = Constants.CONSTANT;
                    }
                    else
                    {
                        hasError = true;
                    }

                    if (hasError)
                    {
                        errors.Add(new TokenPositionHolder { Token = atom, Position = fileLine });
                    }
                    else
                    {
                        var stPosition = symbolTable.GetIndex(atom);
                        if (stPosition == -1) // token not yet in symbol table
                        {
                            symbolTable.Add(atom);
                            stPosition = symbolTable.GetIndex(atom);
                        }

                        internalFormProgramTable.AddSymbol(keyValue[symbolType], symbolType, stPosition);
                    }									
                }
                else
                {
                    errors.Add(new TokenPositionHolder { Token = atom, Position = fileLine });
                }
            }
        }
        
        private static Outputs FindAtomsFromText(string data)
        {
            char[] separatorsToSplit = {'\n', '\r', '\t'};
            List<string> text = data.Split(separatorsToSplit).Select(x => x.Trim()).Where(x => x != string.Empty).ToList();
            Dictionary<string, string> keyValue = Utils.Utils.ReadCodesAtoms();
            
            SymbolTable symbolTable = new ();
            InternalFormProgramTable internalFormProgramTable = new ();
            var errors = new List<TokenPositionHolder>();
            
            for(int i = 0; i < text.Count; i++)
            {
                IEnumerable<string> words = text[i].Split();
                foreach (string word in words)
                {
                    List<string> simpleWords = Utils.Utils.AttemptSplit(word);
                    PutAtomsInTables(symbolTable, internalFormProgramTable, errors, keyValue, simpleWords, i);
                }
            }
            
            return new Outputs(){ InternalFormProgramTable = internalFormProgramTable, SymbolTable = symbolTable, LexicalErrors = errors};
        }
    }
}