using System.Text;
using AtomicConverter.Contracts;
using Microsoft.AspNetCore.Mvc;

namespace AtomicConverter.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TextController: ControllerBase
    {
        private readonly ITextService _textService;

        public TextController(ITextService textService)
        {
            _textService = textService;
        }

        [HttpPost]
        [Route("AddText")]
        public IActionResult AddText([FromBody] Text data)
        {
            _textService.SplitText(data.Message);
            return Ok();
        }
    }
}