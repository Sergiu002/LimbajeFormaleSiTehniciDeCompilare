namespace AtomicConverter.Utils
{
    public class TokenPositionHolder
    {
        public string Code { get; set; }
        public int Position { get; set; }
        public string Token { get; set; }

        public new string ToString()
        {
            return Code + ' ' + Position + ' ' + Token;
        }
    }
}