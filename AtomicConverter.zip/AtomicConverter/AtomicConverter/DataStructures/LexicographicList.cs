using AtomicConverter.Contracts;

namespace AtomicConverter.Utils
{
    public class LexicographicList<T>: ILexicographicList<T> where T: IComparable<T>
    {
        private T[] _elements;
        private int _size;
        private int _capacity;
        
        public LexicographicList(int initialCapacity = 1)
        {
            _elements = new T[initialCapacity];
            _size = 0;
            _capacity = initialCapacity;
        }

        public void Add(T item)
        {
            if (_size == _capacity)
            {
                _capacity *= 2;
                Array.Resize(ref _elements, _capacity);
            }

            int index = 0;
            while (index < _size && string.CompareOrdinal(item.ToString(), _elements[index].ToString()) > 0)
            {
                index++;
            }

            for (int i = _size; i > index; i--)
            {
                _elements[i] = _elements[i - 1];
            }

            _elements[index] = item;
            _size++;
        }

        public void Remove(T item)
        {
            int index = Array.IndexOf(_elements, item, 0, _size);
            if (index >= 0)
            {
                for (int i = index; i < _size - 1; i++)
                {
                    _elements[i] = _elements[i + 1];
                }

                _size--;
            }
        }
        
        public int GetIndex(T item)
        {
            int index = Array.IndexOf(_elements, item, 0, _size);
            return index;
        }

        public void Print()
        {
            for (int i = 0; i < _size; i++)
            {
                Console.WriteLine(_elements[i]);
            }
        }

        public int Length()
        {
            return _size;
        }

        public T GetItem(int index)
        {
            if (index <= _size)
            {
                return _elements[index];
            }
            
            throw new ArgumentOutOfRangeException();
        }
    }
}