using AtomicConverter.Tables;
using AtomicConverter.Utils;

namespace AtomicConverter.DataStructures
{
    public class Outputs
    {
        public SymbolTable SymbolTable { get; set; }

        public InternalFormProgramTable InternalFormProgramTable { get; set; }

        public List<TokenPositionHolder> LexicalErrors { get; set; }
    }
}