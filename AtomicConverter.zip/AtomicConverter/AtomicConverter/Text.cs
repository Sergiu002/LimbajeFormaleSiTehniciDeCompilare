namespace AtomicConverter
{
    public class Text
    {
        public string Message { get; set; }
    }
}